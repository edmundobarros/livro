package papelaria.livro.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import papelaria.livro.entity.MeusLivros;

@Repository
public interface MeusLivrosRepository extends JpaRepository<MeusLivros, Integer>{

}
