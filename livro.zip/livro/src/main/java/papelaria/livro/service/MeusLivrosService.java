package papelaria.livro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import papelaria.livro.entity.MeusLivros;
import papelaria.livro.repository.MeusLivrosRepository;

@Service
public class MeusLivrosService {
	
	@Autowired
	private MeusLivrosRepository meuslivros;
	
	public void saveMeusLivros(MeusLivros livros){
		meuslivros.save(livros);
		
	}
	
	public List<MeusLivros> getAllMeusLivros(){
		return meuslivros.findAll();
	}
	
	public void deleteById(int id) {
		meuslivros.deleteById(id);
	}

}
