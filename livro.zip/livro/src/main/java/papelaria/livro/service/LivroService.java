package papelaria.livro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import papelaria.livro.entity.Livro;
import papelaria.livro.repository.LivroRepository;

@Service
public class LivroService {
	
	@Autowired
	private LivroRepository lRepo;
	
	public void save(Livro l) {
		lRepo.save(l);
	}
	
	public List<Livro> getAllLivros(){
		return lRepo.findAll();
	}

	public Livro getLivroById(int id) {
		return lRepo.findById(id).get();
	}

	public void deleteById(int id) {
		lRepo.deleteById(id);
	}
}
