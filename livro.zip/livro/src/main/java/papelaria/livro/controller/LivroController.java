package papelaria.livro.controller;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import papelaria.livro.entity.Livro;
import papelaria.livro.entity.MeusLivros;
import papelaria.livro.service.LivroService;
import papelaria.livro.service.MeusLivrosService;

@Controller
public class LivroController {
	
	@Autowired
	private LivroService service;
	
	@Autowired
	private MeusLivrosService meusLivrosService;
	
	
	@GetMapping("/")
	public String home() {
		return "home";
	}
	
	@GetMapping("/entrada_livro")
	public String entradaLivro() {
		return "entradaLivro";
	}
	
	@GetMapping("/livros_disponiveis")
	public ModelAndView getAllLivros() {
		List<Livro>list = service.getAllLivros();
		return new ModelAndView("livrosList","livro",list);
	}
	
	@PostMapping("/save")
	public String addLivro(@ModelAttribute Livro l) {
		service.save(l);
		return "redirect:/livros_disponiveis";
	}
	
	@GetMapping("/meus_livros")
	public String getMeusLivros(Model model) {
		List<MeusLivros> list = meusLivrosService.getAllMeusLivros();
		model.addAttribute("livro", list);
		return "meusLivros";
		
	}
	
		
	@RequestMapping("/mylist/{id}")
	public String getMyList(@PathVariable("id") int id) {
		Livro l = service.getLivroById(id);
		MeusLivros ml = new MeusLivros(l.getId(),l,l.getNome(),l.getAutor(),l.getPreco());
		meusLivrosService.saveMeusLivros(ml);
		return "redirect:/meus_livros";
	}
	
	@RequestMapping("/livroEditar/{id}")
	public String livroEditar(@PathVariable("id")int id, Model model) {
		Livro l = service.getLivroById(id);
		model.addAttribute("livro",l);
		return "editarLivro";
	}
	

	@RequestMapping("/livroApagar/{id}")
	public String livroApagar(@PathVariable("id")int id) {
		service.deleteById(id);
		meusLivrosService.deleteById(id);
		return "redirect:/livros_disponiveis";	
		}	
	
	
}
